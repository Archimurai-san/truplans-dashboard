import { useState, useMemo } from "react";

const CONTRACT_TEMPLATE = {
  designScope: [
    { id:"0001", label:"Planning, Zoning & Research", included:true, status:"Not Started" },
    { id:"0002", label:"Design Meeting(s)", included:true, status:"Not Started", qty:1 },
    { id:"0003", label:"Wholesale Showroom Access", included:true, status:"N/A" },
    { id:"0004", label:"Architectural Plans / Construction Documents", included:true, status:"Not Started" },
    { id:"0005", label:"Title 24 Energy Report", included:true, status:"Not Started" },
    { id:"0006", label:"HOA Package & Submission", included:true, status:"Not Started" },
    { id:"0008", label:"Structural Drawings & Engineer Wet Stamp", included:true, status:"Not Started" },
    { id:"0009", label:"Plan Check & Permit Process", included:true, status:"Not Started" },
  ],
  constructionScope: [
    { id:"0100", label:"Pre-Construction Meeting / Project Mgmt", included:true, status:"Not Started" },
    { id:"0101", label:"Site Protection & Temp Toilet", included:true, status:"Not Started" },
    { id:"0102", label:"Demolition, Shoring & De-installations", included:true, status:"Not Started" },
    { id:"0103", label:"Debris & Haul Away", included:true, status:"Not Started" },
    { id:"0104", label:"New Footings", included:false, status:"N/A" },
    { id:"0151", label:"Retrofit Structural Shear Wall", included:false, status:"N/A" },
    { id:"0153", label:"Interior Walls", included:false, status:"N/A" },
    { id:"0154", label:"Low Wall (Pony Wall)", included:true, status:"Not Started" },
    { id:"0155", label:"Floor System Framing (10-Star Proprietary)", included:true, status:"Not Started" },
    { id:"0175", label:"Forced Air Unit (FAU)", included:false, status:"N/A" },
    { id:"0177", label:"Air Ducts / Vents", included:true, status:"Not Started" },
    { id:"0201", label:"Electrical Panel Upgrade / Sub Panel", included:false, status:"N/A" },
    { id:"0202", label:"New Electrical Circuits", included:true, status:"Not Started" },
    { id:"0203", label:"Power Outlets", included:true, status:"Not Started" },
    { id:"0204", label:"Recessed Lights", included:true, status:"Not Started" },
    { id:"0206", label:"Light Switches", included:true, status:"Not Started" },
    { id:"0210", label:"Smoke & Carbon Monoxide Detectors", included:true, status:"Not Started" },
    { id:"0330", label:"Fire Sprinklers", included:true, status:"Not Started" },
    { id:"0400", label:"Stucco / Siding Repair at Windows", included:true, status:"Not Started" },
    { id:"0404", label:"Thermal Insulation", included:true, status:"Not Started" },
    { id:"0405", label:"Insulate New Floor System (R19)", included:true, status:"Not Started" },
    { id:"0406", label:"Drywall (Textured to Match)", included:true, status:"Not Started" },
    { id:"0407", label:"Misc Drywall Patching", included:true, status:"Not Started" },
    { id:"0700", label:"Interior Doors", included:false, status:"N/A" },
    { id:"0708", label:"New Construction Windows (Milgard)", included:true, status:"Not Started" },
    { id:"0752", label:"Baseboards (5\" MDF)", included:true, status:"Not Started" },
    { id:"0754", label:"Stair / Balcony Railing Connection", included:true, status:"Not Started" },
    { id:"0758", label:"Finish Flooring", included:false, status:"N/A" },
    { id:"0759", label:"Painting / Staining", included:false, status:"N/A" },
  ],
  paymentMilestones: [
    { id:1, label:"Deposit – at contract signing", amount:1000, paid:false, paidDate:"" },
    { id:2, label:"House Scanning – at time of scan", amount:1800, paid:false, paidDate:"" },
    { id:3, label:"Design – at first design meeting", amount:7975, paid:false, paidDate:"" },
    { id:4, label:"Material Deposits – pre-construction", amount:3500, paid:false, paidDate:"" },
    { id:5, label:"Prep & Demo – initial delivery", amount:10230, paid:false, paidDate:"" },
    { id:6, label:"Rough Inspection", amount:19775, paid:false, paidDate:"" },
    { id:7, label:"Drywall Screw Inspection", amount:18640, paid:false, paidDate:"" },
    { id:8, label:"Final Inspection – passing", amount:12976, paid:false, paidDate:"" },
  ],
  homeownerObligations: [
    { id:"ho1", label:"Provide house key to contractor for lockbox", done:false },
    { id:"ho2", label:"Provide alarm system access / codes", done:false },
    { id:"ho3", label:"HOA contact info submitted to contractor", done:false },
    { id:"ho4", label:"Signed HOA application + neighbor awareness form", done:false },
    { id:"ho5", label:"HOA application fee / deposit paid by homeowner", done:false },
    { id:"ho6", label:"All plan check & permit fees paid by homeowner", done:false },
    { id:"ho7", label:"Maintain electrical power & water during construction", done:false },
    { id:"ho8", label:"Punch list submitted within 7 days of substantial completion", done:false },
  ],
  hiddenConditionFlags: [
    { id:"hc1", label:"New Footings required (not included – hidden condition §4.0)", flagged:false, notes:"" },
    { id:"hc2", label:"Retrofit Shear Wall required (not included – hidden condition §4.1)", flagged:false, notes:"" },
    { id:"hc3", label:"Lateral analysis required (not in contract)", flagged:false, notes:"" },
    { id:"hc4", label:"T24 / HERS failure – additional inspection & upgrade cost", flagged:false, notes:"" },
    { id:"hc5", label:"Electrical panel inadequate – sub-panel required (§5.2)", flagged:false, notes:"" },
    { id:"hc6", label:"Mold / structural damage / termite found during demo", flagged:false, notes:"" },
    { id:"hc7", label:"Duct soffit required due to routing constraints (§5.1)", flagged:false, notes:"" },
  ],
  changeOrders: [],
  aiAnalysis: null,
};

const NELSON_CONTRACT = {
  id:"CTR-001", type:"Design + Construction",
  contractor:"CALOFT Corp / TRULOFT by TruPlans",
  contractorLic:"CSLB #970476", signedDate:"2026-03-09", totalAmount:75896,
  estStart:"2026-06-01", estCompletion:"2026-07-31", constructionWeeks:"3-4",
  docusignId:"3D6EAD03-4076-40AA-ADB1-C61722D0A1CC",
  designScope: [
    { id:"0001", label:"Planning, Zoning & Research", included:true, status:"In Progress" },
    { id:"0002", label:"Design Meeting(s) – 1 included", included:true, status:"Not Started", qty:1 },
    { id:"0003", label:"Wholesale Showroom Access", included:true, status:"N/A" },
    { id:"0004", label:"Architectural Plans / Construction Documents", included:true, status:"Not Started" },
    { id:"0005", label:"Title 24 Energy Report", included:true, status:"Not Started" },
    { id:"0006", label:"HOA Package & Submission", included:true, status:"Not Started" },
    { id:"0008", label:"Structural Drawings & Engineer Wet Stamp", included:true, status:"Not Started" },
    { id:"0009", label:"Plan Check & Permit – City of Carlsbad", included:true, status:"Not Started" },
  ],
  constructionScope: [
    { id:"0100", label:"Pre-Construction Meeting / Project Mgmt", included:true, status:"Not Started" },
    { id:"0101", label:"Site Protection & Temp Toilet", included:true, status:"Not Started" },
    { id:"0102", label:"Demolition, Shoring & De-installations", included:true, status:"Not Started" },
    { id:"0103", label:"Debris & Haul Away", included:true, status:"Not Started" },
    { id:"0104", label:"New Footings", included:false, status:"N/A" },
    { id:"0151", label:"Retrofit Structural Shear Wall", included:false, status:"N/A" },
    { id:"0153", label:"Interior Walls", included:false, status:"N/A" },
    { id:"0154", label:"Low Wall / Pony Wall (min 42\" + rail cap)", included:true, status:"Not Started" },
    { id:"0155", label:"Floor System Framing – 10 Star Proprietary System", included:true, status:"Not Started" },
    { id:"0175", label:"Forced Air Unit (FAU)", included:false, status:"N/A" },
    { id:"0177", label:"Air Ducts / Vents – 2 new upstairs", included:true, status:"Not Started" },
    { id:"0201", label:"Electrical Panel Upgrade / Sub Panel", included:false, status:"N/A" },
    { id:"0202", label:"New Electrical Circuit – 1 (15amp home run)", included:true, status:"Not Started" },
    { id:"0203", label:"Power Outlets – 7 (tamper resistant arc-fault)", included:true, status:"Not Started" },
    { id:"0204", label:"Recessed LED Lights – 10 (4\" or 6\")", included:true, status:"Not Started" },
    { id:"0206", label:"Light Switches – 3 (dimmer by contractor)", included:true, status:"Not Started" },
    { id:"0210", label:"Smoke & Carbon Monoxide Detectors", included:true, status:"Not Started" },
    { id:"0330", label:"Fire Sprinklers – 4 heads (NFPA code)", included:true, status:"Not Started" },
    { id:"0400", label:"Stucco Repair at 2 New Window Locations", included:true, status:"Not Started" },
    { id:"0404", label:"Thermal Insulation at old window locations", included:true, status:"Not Started" },
    { id:"0405", label:"Floor System Insulation – R19", included:true, status:"Not Started" },
    { id:"0406", label:"Textured Drywall – match existing", included:true, status:"Not Started" },
    { id:"0407", label:"Misc Drywall Patching", included:true, status:"Not Started" },
    { id:"0700", label:"Interior Doors", included:false, status:"N/A" },
    { id:"0708", label:"New Windows – 2 Casement Milgard (enlarge existing)", included:true, status:"Not Started" },
    { id:"0710", label:"Special Windows", included:false, status:"Removed – step-up conflict" },
    { id:"0752", label:"Baseboards – 5\" MDF to match existing", included:true, status:"Not Started" },
    { id:"0754", label:"Stair / Balcony Railing – connect existing to new low wall", included:true, status:"Not Started" },
    { id:"0758", label:"Finish Flooring", included:false, status:"N/A" },
    { id:"0759", label:"Painting / Staining", included:false, status:"N/A" },
  ],
  paymentMilestones: [
    { id:1, label:"Deposit – at contract signing", amount:1000, paid:true, paidDate:"2026-03-09" },
    { id:2, label:"House Scanning – at time of scan", amount:1800, paid:false, paidDate:"" },
    { id:3, label:"Design – at first design meeting", amount:7975, paid:false, paidDate:"" },
    { id:4, label:"Material Deposits – pre-construction meeting", amount:3500, paid:false, paidDate:"" },
    { id:5, label:"Prep & Demo – includes initial material delivery", amount:10230, paid:false, paidDate:"" },
    { id:6, label:"Rough Inspection – at rough inspection", amount:19775, paid:false, paidDate:"" },
    { id:7, label:"Drywall Screw – at drywall screw inspection", amount:18640, paid:false, paidDate:"" },
    { id:8, label:"Final Inspection – at passing final", amount:12976, paid:false, paidDate:"" },
  ],
  homeownerObligations: [
    { id:"ho1", label:"Provide house key to CALOFT for lockbox", done:false },
    { id:"ho2", label:"Provide alarm system access / codes", done:false },
    { id:"ho3", label:"HOA contact info submitted to CALOFT", done:false },
    { id:"ho4", label:"Signed HOA application + neighbor awareness form", done:false },
    { id:"ho5", label:"HOA application fee / deposit paid by homeowner", done:false },
    { id:"ho6", label:"All plan check & permit fees paid by homeowner (§5.0)", done:false },
    { id:"ho7", label:"Maintain electrical power & water during construction", done:false },
    { id:"ho8", label:"Punch list submitted within 7 days of substantial completion", done:false },
  ],
  hiddenConditionFlags: [
    { id:"hc1", label:"New Footings required (not included – §4.0)", flagged:false, notes:"" },
    { id:"hc2", label:"Retrofit Shear Wall required (not included – §4.1)", flagged:false, notes:"" },
    { id:"hc3", label:"Lateral analysis required (not included unless specified)", flagged:false, notes:"" },
    { id:"hc4", label:"T24 / HERS failure – additional inspection & upgrade costs", flagged:false, notes:"" },
    { id:"hc5", label:"Electrical panel inadequate – sub-panel required (§5.2)", flagged:false, notes:"" },
    { id:"hc6", label:"Mold / structural damage / termite found during demo", flagged:false, notes:"" },
    { id:"hc7", label:"Duct soffit required due to routing constraints (§5.1)", flagged:false, notes:"" },
  ],
  changeOrders: [],
  aiAnalysis: {
    generatedAt:"2026-03-24",
    summary:"High ceiling to loft conversion at 7984 Paseo Esmerado, Carlsbad for Natalie Nelson. Total contract $75,896 covering full TruPlans design/engineering and CALOFT construction. Proprietary 10-Star floor system with lifetime structural warranty. 3–4 weeks construction post-permit. Signed via DocuSign 3/9/2026.",
    scopeSummary:"• Convert vaulted/high ceiling to open loft bonus room\n• Low wall (pony wall) min 42\" + decorative rail cap + 2 steps\n• Proprietary 10-Star retrofitted floor diaphragm (lifetime warranty)\n• 2 new enlarged casement windows (Milgard or equal)\n• HVAC: 2 new upstairs ducts\n• Electrical: 1 circuit, 7 outlets, 10 recessed lights, 3 switches, smoke/CO\n• Fire sprinklers: 4 heads\n• Stucco repair at 2 new window locations\n• R19 floor insulation + thermal insulation\n• Textured drywall to match existing\n• 5\" MDF baseboards\n• Railing connection to existing\n• NOT included: footings, shear wall, interior doors, flooring, painting",
    paymentSummary:"8 milestone payments tied to project phases (NOT trade cost). Deposit $1,000 paid 3/9/26. Remaining $74,896 due across 7 milestones from house scanning to final inspection. Credit card accepted with 2.9% surcharge (except deposit). Preferred: direct bank transfer. Late = breach of contract; penalties 3%/week. Insufficient funds = $65 fee + immediate late charge.",
    obligations:"TruPlans must deliver: (0001) Planning & zoning research with City of Carlsbad, (0002) 1 design meeting Mon-Fri 9-5, (0004) Architectural plans & construction documents, (0005) Title 24 energy report, (0006) HOA architectural review package, (0008) Structural drawings with licensed engineer wet stamp, (0009) Plan check submittal, building dept correspondence, permit pull. Homeowner responsible for: ALL permit/plan check fees, HOA fees, T24 upgrade costs if fail, landscape/soils reports if required.",
    riskFlags:[
      { level:"HIGH", text:"Homeowner pays ALL permit & plan check fees separately (§5.0). Carlsbad fees can be $3,000–$8,000+. Confirm client is aware and has budget for this before plan check submittal." },
      { level:"HIGH", text:"Proposal valid 30 days from 3/9/26 — EXPIRES 4/8/2026. Any addenda or amendments must be executed before this date." },
      { level:"HIGH", text:"Hidden conditions clause (§4.0/4.1): footings and shear wall currently N/A — if found inadequate during structural review, cost falls entirely on homeowner. Monitor closely during engineering phase." },
      { level:"MEDIUM", text:"T24/HERS risk (§3.1A): if energy score fails, homeowner pays additional inspection + upgrade work. Engage Title 24 consultant early to assess risk." },
      { level:"MEDIUM", text:"Verbal change orders still billable under CA B&P 7159(e)(3)(C) (§3.4). ALL scope changes must be documented in writing — instruct client and field team accordingly." },
      { level:"MEDIUM", text:"Start date contingent on permit issuance. Estimated Jun-26 may shift if plan check takes longer than expected. Communicate proactively with client." },
      { level:"LOW", text:"3-day right to cancel expired 3/12/26. Post-cancellation: contractor bills T&M at $65/hr skilled / $35/hr admin for all work performed." },
      { level:"LOW", text:"Photography/video permission granted to CALOFT for marketing (§2.3/2.4). Chris Doering to schedule post-completion session." },
    ],
    actionItems:[
      { done:true,  text:"Deposit $1,000 received — confirmed via DocuSign 3/9/2026" },
      { done:false, text:"Confirm Natalie Nelson's HOA contact info and submit to CALOFT" },
      { done:false, text:"Schedule house scanning appointment ($1,800 due at scan)" },
      { done:false, text:"Initiate Planning & Zoning research with City of Carlsbad (item 0001)" },
      { done:false, text:"Schedule first design meeting — Mon–Fri 9–5 only, 1 included" },
      { done:false, text:"Order Title 24 / energy calculations (item 0005)" },
      { done:false, text:"Prepare HOA architectural review package (item 0006)" },
      { done:false, text:"Coordinate licensed structural engineer for wet-stamp drawings (item 0008)" },
      { done:false, text:"Submit plans to City of Carlsbad building dept for plan check (item 0009)" },
      { done:false, text:"Confirm client understands permit fees are NOT included in contract total" },
    ],
  },
};

const PROJECTS_INIT = [
  { id:"TRU-001", name:"Smith Residence Addition", client:"John & Mary Smith", city:"Rancho Cucamonga", type:"Room Addition", designer:"Radovan", status:"In Progress", phase:"Construction Docs", start:"2026-01-15", end:"2026-04-30", pct:65, stamp:"Yes", permit:"Pending", contract:18500, invoiced:12000, contracts:[] },
  { id:"TRU-002", name:"Patel ADU Build", client:"Raj Patel", city:"Upland", type:"ADU - New", designer:"Willis", status:"In Progress", phase:"Design Dev", start:"2026-02-01", end:"2026-05-15", pct:40, stamp:"No", permit:"No", contract:22000, invoiced:8000, contracts:[] },
  { id:"TRU-003", name:"Johnson Garage Conv.", client:"Mike Johnson", city:"Fontana", type:"Garage Conv.", designer:"Radovan", status:"In Progress", phase:"Permit Docs", start:"2026-01-20", end:"2026-03-31", pct:80, stamp:"Yes", permit:"Yes", contract:9500, invoiced:9500, contracts:[] },
  { id:"TRU-004", name:"Chen Commercial TI", client:"Amy Chen", city:"Ontario", type:"Commercial Int.", designer:"Molly", status:"On Hold", phase:"Schematic", start:"2025-12-01", end:"2026-06-30", pct:20, stamp:"No", permit:"No", contract:45000, invoiced:5000, contracts:[] },
  { id:"TRU-005", name:"Garcia 2nd Story Add.", client:"Carlos Garcia", city:"Rancho Cucamonga", type:"Room Addition", designer:"Shirley", status:"In Progress", phase:"Construction Docs", start:"2026-02-10", end:"2026-05-01", pct:55, stamp:"Yes", permit:"Pending", contract:31000, invoiced:15000, contracts:[] },
  { id:"TRU-006", name:"Williams ADU", client:"Sandra Williams", city:"Pomona", type:"ADU - Garage Conv.", designer:"Radovan", status:"In Progress", phase:"Design Dev", start:"2026-02-20", end:"2026-06-15", pct:30, stamp:"No", permit:"No", contract:16000, invoiced:4000, contracts:[] },
  { id:"TRU-007", name:"Park Kitchen Remodel", client:"James Park", city:"Chino Hills", type:"Commercial Int.", designer:"Willis", status:"Completed", phase:"Closeout", start:"2025-11-01", end:"2026-02-28", pct:100, stamp:"Yes", permit:"Yes", contract:12000, invoiced:12000, contracts:[] },
  { id:"TRU-008", name:"Lee New ADU", client:"Linda Lee", city:"Montclair", type:"ADU - New", designer:"Molly", status:"In Progress", phase:"Permit Docs", start:"2026-01-05", end:"2026-04-15", pct:70, stamp:"Yes", permit:"Pending", contract:19500, invoiced:12000, contracts:[] },
  { id:"TRU-009", name:"Hernandez Addition", client:"Maria Hernandez", city:"Ontario", type:"Room Addition", designer:"Radovan", status:"In Progress", phase:"Schematic", start:"2026-03-01", end:"2026-07-31", pct:10, stamp:"No", permit:"No", contract:24000, invoiced:3000, contracts:[] },
  { id:"TRU-010", name:"Kim Accessory Struct.", client:"David Kim", city:"Upland", type:"ADU - New", designer:"Shirley", status:"In Progress", phase:"Design Dev", start:"2026-02-15", end:"2026-06-01", pct:35, stamp:"No", permit:"No", contract:14000, invoiced:5000, contracts:[] },
  { id:"TRU-011", name:"Torres Office TI", client:"Rosa Torres", city:"Fontana", type:"Commercial Int.", designer:"Willis", status:"In Progress", phase:"Construction Docs", start:"2025-12-15", end:"2026-04-01", pct:75, stamp:"Yes", permit:"Yes", contract:38000, invoiced:28000, contracts:[] },
  { id:"TRU-012", name:"Nelson Loft Conversion", client:"Natalie Nelson", city:"Carlsbad", type:"High Ceiling Conv.", designer:"Radovan", status:"In Progress", phase:"Design Dev", start:"2026-03-09", end:"2026-07-31", pct:5, stamp:"No", permit:"No", contract:75896, invoiced:1000, contracts:[NELSON_CONTRACT] },
];

const TASKS_INIT = [
  { job:"TRU-001", desc:"Finalize floor plan per client revisions", assigned:"Radovan", priority:"High", status:"In Progress", due:"2026-03-25" },
  { job:"TRU-001", desc:"Submit for engineer review", assigned:"Radovan", priority:"High", status:"Pending", due:"2026-03-28" },
  { job:"TRU-002", desc:"Complete Title 24 energy calcs", assigned:"Willis", priority:"Medium", status:"In Progress", due:"2026-03-30" },
  { job:"TRU-003", desc:"Respond to plan check comments", assigned:"Radovan", priority:"High", status:"In Progress", due:"2026-03-24" },
  { job:"TRU-005", desc:"Structural coordination set", assigned:"Shirley", priority:"High", status:"In Progress", due:"2026-03-26" },
  { job:"TRU-006", desc:"Site visit and measurements", assigned:"Radovan", priority:"Medium", status:"Not Started", due:"2026-03-27" },
  { job:"TRU-008", desc:"Follow up with City of Montclair", assigned:"Molly", priority:"High", status:"Pending", due:"2026-03-24" },
  { job:"TRU-009", desc:"Develop 3 schematic options", assigned:"Radovan", priority:"Medium", status:"In Progress", due:"2026-04-05" },
  { job:"TRU-011", desc:"Final punch list walkthrough", assigned:"Willis", priority:"High", status:"In Progress", due:"2026-03-25" },
  { job:"TRU-012", desc:"Schedule house scanning – Natalie Nelson", assigned:"Radovan", priority:"High", status:"Not Started", due:"2026-03-28" },
];

const PHASES = ["Schematic","Design Dev","Construction Docs","Permit Docs","Permit Review","Construction","Closeout"];
const STATUS_COLOR = {
  "In Progress":{ bg:"#1a3a5c",text:"#5bb8f5",dot:"#5bb8f5" },
  "Completed":  { bg:"#1a3d2b",text:"#52d68a",dot:"#52d68a" },
  "On Hold":    { bg:"#3d2a0d",text:"#f0a842",dot:"#f0a842" },
  "Not Started":{ bg:"#1e1e2e",text:"#888",dot:"#888" },
  "Pending":    { bg:"#2d2010",text:"#f0a842",dot:"#f0a842" },
  "N/A":        { bg:"#111",text:"#444",dot:"#444" },
};
const PRIORITY_COLOR = { High:"#e74c3c",Medium:"#f39c12",Low:"#3498db" };
const DC = { Radovan:"#e94560",Willis:"#3498db",Molly:"#9b59b6",Shirley:"#27ae60",Ayana:"#f39c12",Chris:"#1abc9c" };
const fmt$ = n => "$" + Number(n).toLocaleString();
const GANTT_S = new Date("2026-01-01"), GANTT_E = new Date("2026-12-31");
const TDAYS = (GANTT_E - GANTT_S) / 86400000;
function gBar(s,e) {
  const sd=new Date(s),ed=new Date(e);
  const l=Math.max(0,(sd-GANTT_S)/86400000/TDAYS*100);
  const w=Math.min(100-l,(ed-sd)/86400000/TDAYS*100);
  return {left:l.toFixed(1)+"%",width:Math.max(0.5,w).toFixed(1)+"%"};
}

function Av({name,size=28}){const c=DC[name]||"#666";return<div style={{width:size,height:size,borderRadius:"50%",background:c+"33",border:`1.5px solid ${c}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*.38,fontWeight:700,color:c,flexShrink:0,fontFamily:"monospace"}}>{name[0]}</div>;}
function Sb({status}){const c=STATUS_COLOR[status]||STATUS_COLOR["Not Started"];return<span style={{background:c.bg,color:c.text,padding:"2px 8px",borderRadius:99,fontSize:10,fontWeight:600,letterSpacing:".5px",whiteSpace:"nowrap",display:"inline-flex",alignItems:"center",gap:4}}><span style={{width:5,height:5,borderRadius:"50%",background:c.dot,display:"inline-block"}}/>{status}</span>;}
function Pb({pct,color="#e94560"}){return<div style={{background:"#1a1a2e",borderRadius:99,height:5,width:"100%",overflow:"hidden"}}><div style={{height:"100%",width:pct+"%",borderRadius:99,background:pct===100?"#52d68a":color,transition:"width .4s"}}/></div>;}
function ST({children,color="#e94560"}){return<div style={{fontSize:10,fontWeight:700,color,letterSpacing:"2px",textTransform:"uppercase",marginBottom:14,fontFamily:"monospace"}}>{children}</div>;}

const S={
  app:{minHeight:"100vh",background:"#0d0d1a",color:"#e0e0e0",fontFamily:"Georgia,serif"},
  nav:{background:"#0a0a15",borderBottom:"1px solid #1e1e3a",padding:"0 24px",display:"flex",alignItems:"center",gap:0,position:"sticky",top:0,zIndex:100},
  logo:{color:"#e94560",fontWeight:700,fontSize:16,letterSpacing:"2px",marginRight:32,padding:"14px 0",fontFamily:"monospace"},
  tab:a=>({padding:"14px 18px",cursor:"pointer",fontSize:11,letterSpacing:"1px",fontWeight:a?700:400,color:a?"#e94560":"#888",background:"none",border:"none",borderBottom:a?"2px solid #e94560":"2px solid transparent",fontFamily:"monospace",textTransform:"uppercase"}),
  main:{padding:"24px",maxWidth:1500,margin:"0 auto"},
  card:{background:"#12122a",border:"1px solid #1e1e3a",borderRadius:8,padding:"16px 20px"},
  metric:{background:"#12122a",border:"1px solid #1e1e3a",borderRadius:8,padding:"20px",flex:1,minWidth:140},
  sel:{background:"#12122a",border:"1px solid #2a2a4a",color:"#ccc",padding:"5px 10px",borderRadius:4,fontSize:11,cursor:"pointer",fontFamily:"monospace"},
  tbl:{width:"100%",borderCollapse:"collapse"},
  th:{textAlign:"left",padding:"8px 10px",fontSize:10,color:"#e94560",letterSpacing:"1.5px",textTransform:"uppercase",borderBottom:"1px solid #1e1e3a",fontFamily:"monospace",whiteSpace:"nowrap"},
  td:{padding:"9px 10px",fontSize:11,borderBottom:"1px solid #0f0f22",verticalAlign:"middle"},
  btn:{background:"#e94560",color:"#fff",border:"none",padding:"7px 16px",borderRadius:4,fontSize:11,cursor:"pointer",fontWeight:700,letterSpacing:"1px",fontFamily:"monospace"},
  ghost:{background:"transparent",color:"#e94560",border:"1px solid #e94560",padding:"6px 14px",borderRadius:4,fontSize:11,cursor:"pointer",fontWeight:700,letterSpacing:"1px",fontFamily:"monospace"},
  input:{background:"#0d0d1a",border:"1px solid #2a2a4a",color:"#e0e0e0",padding:"7px 10px",borderRadius:4,fontSize:12,width:"100%",boxSizing:"border-box",fontFamily:"Georgia,serif"},
  label:{fontSize:10,color:"#888",letterSpacing:"1px",textTransform:"uppercase",fontFamily:"monospace",display:"block",marginBottom:4},
  ov:{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:200,display:"flex",alignItems:"flex-start",justifyContent:"center",paddingTop:30,overflowY:"auto"},
  mod:{background:"#12122a",border:"1px solid #2a2a4a",borderRadius:10,padding:"28px",width:"95%",maxWidth:960,marginBottom:40},
};

function ContractModule({project,onClose}){
  const [ci,setCi]=useState(project.contracts.length>0?0:null);
  const [ctab,setCtab]=useState("overview");
  const [ctrs,setCtrs]=useState(project.contracts);
  const [analyzing,setAnalyzing]=useState(false);
  const [pdfTxt,setPdfTxt]=useState("");
  const [aiRes,setAiRes]=useState(null);
  const [newCO,setNewCO]=useState({date:"",description:"",amount:"",status:"Pending"});

  const ctr=ci!==null?ctrs[ci]:null;
  const paid=ctr?ctr.paymentMilestones.filter(m=>m.paid).reduce((a,m)=>a+m.amount,0):0;
  const due=ctr?ctr.totalAmount-paid:0;
  const pctP=ctr?Math.round(paid/ctr.totalAmount*100):0;

  async function analyze(){
    if(!pdfTxt.trim())return;
    setAnalyzing(true);
    try{
      const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:`You are an expert architectural project manager at TruPlans Inc., a California residential design firm. Analyze this contract and return ONLY valid JSON (no markdown, no backticks):
{"summary":"2-3 sentence overview","scopeSummary":"included items as bullet list with \\n separators","paymentSummary":"payment schedule summary","obligations":"what TruPlans must deliver","riskFlags":[{"level":"HIGH|MEDIUM|LOW","text":"description"}],"actionItems":[{"done":false,"text":"action item"}]}

CONTRACT:
${pdfTxt.slice(0,8000)}`}]})});
      const d=await r.json();
      const raw=d.content?.[0]?.text||"{}";
      const parsed=JSON.parse(raw.replace(/```json|```/g,"").trim());
      const final={...parsed,generatedAt:new Date().toISOString().slice(0,10)};
      setAiRes(final);
      setCtrs(prev=>prev.map((c,i)=>i===ci?{...c,aiAnalysis:final}:c));
    }catch(e){setAiRes({error:"Analysis failed. Paste contract text and retry."});}
    setAnalyzing(false);
  }

  const tog=(section,id)=>setCtrs(prev=>prev.map((c,i)=>{if(i!==ci)return c;return{...c,[section]:c[section].map(s=>s.id!==id?s:{...s,status:s.status==="Completed"?"In Progress":s.status==="In Progress"?"Not Started":"Completed"})};}));
  const togPay=idx=>setCtrs(prev=>prev.map((c,i)=>i!==ci?c:{...c,paymentMilestones:c.paymentMilestones.map((m,mi)=>mi!==idx?m:{...m,paid:!m.paid,paidDate:!m.paid?new Date().toISOString().slice(0,10):""})}));
  const togHO=id=>setCtrs(prev=>prev.map((c,i)=>i!==ci?c:{...c,homeownerObligations:c.homeownerObligations.map(o=>o.id!==id?o:{...o,done:!o.done})}));
  const togHC=id=>setCtrs(prev=>prev.map((c,i)=>i!==ci?c:{...c,hiddenConditionFlags:c.hiddenConditionFlags.map(h=>h.id!==id?h:{...h,flagged:!h.flagged})}));
  const addCO=()=>{if(!newCO.description)return;setCtrs(prev=>prev.map((c,i)=>i!==ci?c:{...c,changeOrders:[...c.changeOrders,{...newCO,id:`CO-${Date.now()}`,amount:parseFloat(newCO.amount)||0}]}));setNewCO({date:"",description:"",amount:"",status:"Pending"});};
  const addContract=()=>{const nc={id:`CTR-${Date.now()}`,type:"Design + Construction",contractor:"",contractorLic:"",signedDate:"",totalAmount:0,estStart:"",estCompletion:"",constructionWeeks:"",docusignId:"",...JSON.parse(JSON.stringify(CONTRACT_TEMPLATE)),aiAnalysis:null};setCtrs(p=>[...p,nc]);setCi(ctrs.length);};
  const clearAI=()=>{setAiRes(null);setCtrs(prev=>prev.map((c,i)=>i===ci?{...c,aiAnalysis:null}:c));};

  const CTABS=["overview","design scope","construction scope","payments","homeowner","hidden conditions","change orders","ai analysis"];
  const ai=aiRes||(ctr?.aiAnalysis);

  return(
    <div style={S.ov} onClick={onClose}>
      <div style={{...S.mod}} onClick={e=>e.stopPropagation()}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:20}}>
          <div>
            <div style={{fontSize:10,color:"#e94560",letterSpacing:"2px",fontFamily:"monospace"}}>CONTRACT MODULE</div>
            <div style={{fontSize:18,fontWeight:700,color:"#f0f0f0",marginTop:2}}>{project.name}</div>
            <div style={{fontSize:11,color:"#888"}}>{project.client} · {project.city}</div>
          </div>
          <div style={{display:"flex",gap:8}}>
            <button style={{...S.ghost,fontSize:10}} onClick={addContract}>+ Add Contract</button>
            <button style={{...S.ghost,fontSize:10,color:"#555",borderColor:"#333"}} onClick={onClose}>✕</button>
          </div>
        </div>

        {ctrs.length===0?(
          <div style={{textAlign:"center",padding:"48px 0",color:"#555"}}>
            <div style={{fontSize:32,marginBottom:12}}>📄</div>
            <div style={{fontSize:13,marginBottom:16}}>No contracts attached yet.</div>
            <button style={S.btn} onClick={addContract}>+ Add First Contract</button>
          </div>
        ):(
          <>
            {ctrs.length>1&&<div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>{ctrs.map((c,i)=><button key={c.id} onClick={()=>setCi(i)} style={{...S.ghost,...(ci===i?{background:"#e94560",color:"#fff"}:{}),fontSize:10}}>{c.id} — {c.type}</button>)}</div>}

            {ctr&&<>
              <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:8,marginBottom:14}}>
                {[["Total",fmt$(ctr.totalAmount),"#f0f0f0"],["Paid",fmt$(paid),"#52d68a"],["Outstanding",fmt$(due),due>0?"#f0a842":"#52d68a"],["Est. Start",ctr.estStart||"TBD","#ccc"],["Completion",ctr.estCompletion||"TBD","#ccc"]].map(([l,v,c])=>(
                  <div key={l} style={{background:"#0d0d1a",borderRadius:6,padding:"10px 12px"}}><div style={{fontSize:9,color:"#555",letterSpacing:"1px",textTransform:"uppercase",fontFamily:"monospace"}}>{l}</div><div style={{fontSize:13,fontWeight:700,color:c,marginTop:3,fontFamily:"monospace"}}>{v}</div></div>
                ))}
              </div>
              <div style={{marginBottom:16}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:10,color:"#888",fontFamily:"monospace"}}><span>Payment progress</span><span style={{color:"#52d68a"}}>{pctP}%</span></div><Pb pct={pctP} color="#27ae60"/></div>

              <div style={{display:"flex",gap:0,borderBottom:"1px solid #1e1e3a",marginBottom:18,flexWrap:"wrap"}}>
                {CTABS.map(t=><button key={t} onClick={()=>setCtab(t)} style={{padding:"8px 12px",cursor:"pointer",fontSize:9,letterSpacing:"1px",fontWeight:ctab===t?700:400,color:ctab===t?"#e94560":"#555",background:"none",border:"none",borderBottom:ctab===t?"2px solid #e94560":"2px solid transparent",fontFamily:"monospace",textTransform:"uppercase"}}>{t}</button>)}
              </div>

              {/* OVERVIEW */}
              {ctab==="overview"&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["Contractor",ctr.contractor],["License",ctr.contractorLic],["Contract Type",ctr.type],["Signed",ctr.signedDate],["DocuSign ID",ctr.docusignId],["Construction",ctr.constructionWeeks+" weeks"]].map(([l,v])=>(
                  <div key={l} style={{background:"#0d0d1a",padding:"10px 12px",borderRadius:4}}><div style={{fontSize:9,color:"#555",fontFamily:"monospace",letterSpacing:"1px",textTransform:"uppercase"}}>{l}</div><div style={{fontSize:11,color:"#ccc",marginTop:3}}>{v||"—"}</div></div>
                ))}
              </div>}

              {/* DESIGN SCOPE */}
              {ctab==="design scope"&&<div>
                <ST>TruPlans Design Deliverables (Items 0001–0009)</ST>
                {ctr.designScope.map(item=>(
                  <div key={item.id} onClick={()=>item.included&&tog("designScope",item.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 10px",borderRadius:4,marginBottom:4,background:item.included?"#0d0d1a":"#080810",cursor:item.included?"pointer":"default",opacity:item.included?1:0.35}}>
                    <div style={{width:18,height:18,borderRadius:3,border:`1.5px solid ${item.status==="Completed"?"#27ae60":item.status==="In Progress"?"#3498db":"#333"}`,background:item.status==="Completed"?"#27ae6033":item.status==="In Progress"?"#3498db22":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                      {item.status==="Completed"&&<span style={{fontSize:10,color:"#27ae60"}}>✓</span>}
                      {item.status==="In Progress"&&<span style={{fontSize:8,color:"#3498db"}}>●</span>}
                    </div>
                    <span style={{fontSize:10,color:"#e94560",minWidth:36,fontFamily:"monospace"}}>{item.id}</span>
                    <span style={{flex:1,fontSize:11,color:item.included?"#ccc":"#444"}}>{item.label}</span>
                    <Sb status={item.included?item.status:"N/A"}/>
                  </div>
                ))}
                <div style={{fontSize:10,color:"#444",marginTop:8,fontFamily:"monospace"}}>Click to cycle: Not Started → In Progress → Completed</div>
              </div>}

              {/* CONSTRUCTION SCOPE */}
              {ctab==="construction scope"&&<div>
                <ST>CALOFT Construction Scope (Items 0100–0759)</ST>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
                  {ctr.constructionScope.map(item=>(
                    <div key={item.id} onClick={()=>item.included&&tog("constructionScope",item.id)} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",borderRadius:4,background:item.included?"#0d0d1a":"#080810",cursor:item.included?"pointer":"default",opacity:item.included?1:0.3}}>
                      <div style={{width:14,height:14,borderRadius:2,border:`1.5px solid ${item.status==="Completed"?"#27ae60":"#333"}`,background:item.status==="Completed"?"#27ae6033":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                        {item.status==="Completed"&&<span style={{fontSize:9,color:"#27ae60"}}>✓</span>}
                      </div>
                      <span style={{fontSize:9,color:"#555",minWidth:32,fontFamily:"monospace"}}>{item.id}</span>
                      <span style={{fontSize:10,color:item.included?"#bbb":"#333",flex:1}}>{item.label}</span>
                      {!item.included&&<span style={{fontSize:9,color:"#333",fontFamily:"monospace"}}>N/I</span>}
                    </div>
                  ))}
                </div>
              </div>}

              {/* PAYMENTS */}
              {ctab==="payments"&&<div>
                <ST>Payment Milestone Tracker</ST>
                <div style={{marginBottom:12,fontSize:10,color:"#f0a842",padding:"8px 12px",background:"#1a0d00",borderRadius:4,borderLeft:"3px solid #f0a842",fontFamily:"monospace"}}>
                  ⚠ Payments are milestone-based, NOT trade-cost based. Late = 3%/week penalty + possible project suspension.
                </div>
                {ctr.paymentMilestones.map((m,i)=>(
                  <div key={m.id} onClick={()=>togPay(i)} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 12px",borderRadius:6,marginBottom:6,background:m.paid?"#1a3d2b":"#0d0d1a",border:`1px solid ${m.paid?"#27ae6033":"#1e1e3a"}`,cursor:"pointer"}}>
                    <div style={{width:22,height:22,borderRadius:"50%",border:`2px solid ${m.paid?"#27ae60":"#333"}`,background:m.paid?"#27ae60":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:10,color:"#fff",fontWeight:700}}>{m.paid?"✓":m.id}</div>
                    <div style={{flex:1}}>
                      <div style={{fontSize:11,color:m.paid?"#52d68a":"#ccc"}}>{m.label}</div>
                      {m.paid&&m.paidDate&&<div style={{fontSize:9,color:"#52d68a55",marginTop:1,fontFamily:"monospace"}}>Paid {m.paidDate}</div>}
                    </div>
                    <div style={{fontSize:13,fontWeight:700,color:m.paid?"#52d68a":"#f0a842",fontFamily:"monospace"}}>{fmt$(m.amount)}</div>
                  </div>
                ))}
                <div style={{display:"flex",justifyContent:"space-between",padding:"12px",background:"#0a0a15",borderRadius:6,marginTop:8}}>
                  <span style={{fontSize:11,color:"#888",fontFamily:"monospace"}}>PAID / TOTAL</span>
                  <span style={{fontSize:14,fontWeight:700,color:"#52d68a",fontFamily:"monospace"}}>{fmt$(paid)} / {fmt$(ctr.totalAmount)}</span>
                </div>
              </div>}

              {/* HOMEOWNER OBLIGATIONS */}
              {ctab==="homeowner"&&<div>
                <ST>Homeowner Obligations Checklist</ST>
                <div style={{marginBottom:12,fontSize:10,color:"#3498db",padding:"8px 12px",background:"#0a0f1a",borderRadius:4,borderLeft:"3px solid #3498db",fontFamily:"monospace"}}>
                  Track these to prevent delays. Missing items = your deliverables get blocked.
                </div>
                {ctr.homeownerObligations.map(o=>(
                  <div key={o.id} onClick={()=>togHO(o.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:4,marginBottom:5,background:o.done?"#1a3d2b":"#0d0d1a",cursor:"pointer",border:`1px solid ${o.done?"#27ae6033":"#1e1e3a"}`}}>
                    <div style={{width:18,height:18,borderRadius:3,border:`1.5px solid ${o.done?"#27ae60":"#444"}`,background:o.done?"#27ae6033":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{o.done&&<span style={{fontSize:11,color:"#27ae60"}}>✓</span>}</div>
                    <span style={{fontSize:11,color:o.done?"#52d68a":"#ccc"}}>{o.label}</span>
                  </div>
                ))}
              </div>}

              {/* HIDDEN CONDITIONS */}
              {ctab==="hidden conditions"&&<div>
                <ST color="#e74c3c">Hidden Condition Risk Flags (§4.0 / §4.1)</ST>
                <div style={{marginBottom:12,fontSize:10,color:"#e74c3c",padding:"8px 12px",background:"#1a0808",borderRadius:4,borderLeft:"3px solid #e74c3c",fontFamily:"monospace"}}>
                  Per §4.0–4.1: hidden conditions = additional cost to homeowner. Flag any that arise during design or construction.
                </div>
                {ctr.hiddenConditionFlags.map(h=>(
                  <div key={h.id} onClick={()=>togHC(h.id)} style={{display:"flex",alignItems:"flex-start",gap:10,padding:"10px 12px",borderRadius:4,marginBottom:5,background:h.flagged?"#2d0d0d":"#0d0d1a",cursor:"pointer",border:`1px solid ${h.flagged?"#e74c3c55":"#1e1e3a"}`}}>
                    <div style={{width:18,height:18,borderRadius:3,border:`1.5px solid ${h.flagged?"#e74c3c":"#444"}`,background:h.flagged?"#e74c3c33":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{h.flagged&&<span style={{fontSize:11,color:"#e74c3c"}}>!</span>}</div>
                    <span style={{fontSize:11,color:h.flagged?"#e74c3c":"#aaa",flex:1}}>{h.label}</span>
                    {h.flagged&&<span style={{fontSize:9,color:"#e74c3c",fontFamily:"monospace",fontWeight:700}}>FLAGGED</span>}
                  </div>
                ))}
              </div>}

              {/* CHANGE ORDERS */}
              {ctab==="change orders"&&<div>
                <ST color="#9b59b6">Change Order Log (§3.3 / §3.4)</ST>
                <div style={{marginBottom:12,fontSize:10,color:"#9b59b6",padding:"8px 12px",background:"#0f0a1a",borderRadius:4,borderLeft:"3px solid #9b59b6",fontFamily:"monospace"}}>
                  Per CA B&P 7159: verbal changes are still billable. Document ALL changes here before work begins.
                </div>
                {ctr.changeOrders.length===0&&<div style={{color:"#444",fontSize:11,marginBottom:16}}>No change orders logged.</div>}
                {ctr.changeOrders.map(co=>(
                  <div key={co.id} style={{background:"#0d0d1a",border:"1px solid #2a2a4a",borderRadius:6,padding:"12px",marginBottom:8}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div><div style={{fontSize:10,color:"#9b59b6",fontFamily:"monospace"}}>{co.id} · {co.date}</div><div style={{fontSize:11,color:"#ccc",marginTop:3}}>{co.description}</div></div>
                      <div style={{display:"flex",gap:8,alignItems:"center"}}><span style={{fontSize:12,fontWeight:700,color:"#f0a842",fontFamily:"monospace"}}>{co.amount>=0?"+":""}{fmt$(co.amount)}</span><Sb status={co.status}/></div>
                    </div>
                  </div>
                ))}
                <div style={{background:"#0a0a15",border:"1px solid #2a2a4a",borderRadius:6,padding:"14px",marginTop:8}}>
                  <div style={{fontSize:10,color:"#9b59b6",letterSpacing:"1px",fontFamily:"monospace",marginBottom:10}}>+ NEW CHANGE ORDER</div>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 2fr 1fr 100px",gap:8,alignItems:"end"}}>
                    <div><label style={S.label}>Date</label><input type="date" style={S.input} value={newCO.date} onChange={e=>setNewCO({...newCO,date:e.target.value})}/></div>
                    <div><label style={S.label}>Description</label><input style={S.input} value={newCO.description} onChange={e=>setNewCO({...newCO,description:e.target.value})} placeholder="Scope change..."/></div>
                    <div><label style={S.label}>Amount ($)</label><input type="number" style={S.input} value={newCO.amount} onChange={e=>setNewCO({...newCO,amount:e.target.value})} placeholder="0"/></div>
                    <button style={S.btn} onClick={addCO}>Add</button>
                  </div>
                </div>
              </div>}

              {/* AI ANALYSIS */}
              {ctab==="ai analysis"&&<div>
                <ST>AI Contract Analysis</ST>
                {!ai?(
                  <div style={{background:"#0a0a15",border:"1px solid #2a2a4a",borderRadius:8,padding:"20px"}}>
                    <div style={{fontSize:11,color:"#888",marginBottom:12,lineHeight:1.6}}>Paste the contract text below. The AI will extract key obligations, risk flags, scope summary, payment breakdown, and action items tailored to TruPlans' role as the design firm.</div>
                    <textarea style={{...S.input,height:140,resize:"vertical",marginBottom:12,fontSize:11}} placeholder="Paste contract text here..." value={pdfTxt} onChange={e=>setPdfTxt(e.target.value)}/>
                    <button style={{...S.btn,opacity:analyzing?0.6:1}} onClick={analyze} disabled={analyzing}>{analyzing?"⏳ Analyzing...":"🤖 Analyze Contract"}</button>
                  </div>
                ):(
                  <div>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                      <div style={{fontSize:10,color:"#555",fontFamily:"monospace"}}>Generated: {ai.generatedAt||"just now"}</div>
                      <button style={{...S.ghost,fontSize:10}} onClick={clearAI}>Re-analyze</button>
                    </div>
                    {ai.error?<div style={{color:"#e74c3c",fontSize:11}}>{ai.error}</div>:<>
                      <div style={{background:"#0d0d1a",borderRadius:6,padding:"14px",marginBottom:12,borderLeft:"3px solid #e94560"}}>
                        <div style={{fontSize:10,color:"#e94560",fontFamily:"monospace",letterSpacing:"1px",marginBottom:6}}>PROJECT SUMMARY</div>
                        <div style={{fontSize:11,color:"#ccc",lineHeight:1.6}}>{ai.summary}</div>
                      </div>
                      {ai.riskFlags?.length>0&&<div style={{marginBottom:12}}>
                        <div style={{fontSize:10,color:"#e74c3c",fontFamily:"monospace",letterSpacing:"1px",marginBottom:8}}>RISK FLAGS</div>
                        {ai.riskFlags.map((r,i)=>(
                          <div key={i} style={{display:"flex",gap:10,padding:"8px 12px",borderRadius:4,marginBottom:5,background:r.level==="HIGH"?"#200a0a":r.level==="MEDIUM"?"#1a1000":"#0a0f1a",borderLeft:`3px solid ${r.level==="HIGH"?"#e74c3c":r.level==="MEDIUM"?"#f39c12":"#3498db"}`}}>
                            <span style={{fontSize:9,fontWeight:700,color:r.level==="HIGH"?"#e74c3c":r.level==="MEDIUM"?"#f39c12":"#3498db",minWidth:52,fontFamily:"monospace",marginTop:1}}>{r.level}</span>
                            <span style={{fontSize:11,color:"#ccc",lineHeight:1.5}}>{r.text}</span>
                          </div>
                        ))}
                      </div>}
                      {ai.actionItems?.length>0&&<div style={{marginBottom:12}}>
                        <div style={{fontSize:10,color:"#27ae60",fontFamily:"monospace",letterSpacing:"1px",marginBottom:8}}>ACTION ITEMS</div>
                        {ai.actionItems.map((item,i)=>(
                          <div key={i} style={{display:"flex",alignItems:"flex-start",gap:8,padding:"7px 10px",borderRadius:4,marginBottom:4,background:"#0d0d1a"}}>
                            <div style={{width:16,height:16,borderRadius:"50%",border:`1.5px solid ${item.done?"#27ae60":"#333"}`,background:item.done?"#27ae6033":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:10,marginTop:1}}>{item.done&&"✓"}</div>
                            <span style={{fontSize:11,color:item.done?"#52d68a":"#ccc",lineHeight:1.5,textDecoration:item.done?"line-through":"none"}}>{item.text}</span>
                          </div>
                        ))}
                      </div>}
                      {[["Scope Summary",ai.scopeSummary,"#27ae60"],["TruPlans Obligations",ai.obligations,"#3498db"],["Payment Summary",ai.paymentSummary,"#f0a842"]].map(([title,content,color])=>content&&(
                        <div key={title} style={{background:"#0d0d1a",borderRadius:6,padding:"12px",marginBottom:10,borderLeft:`3px solid ${color}`}}>
                          <div style={{fontSize:10,color,fontFamily:"monospace",letterSpacing:"1px",marginBottom:6}}>{title.toUpperCase()}</div>
                          <div style={{fontSize:11,color:"#bbb",lineHeight:1.7,whiteSpace:"pre-line"}}>{content}</div>
                        </div>
                      ))}
                    </>}
                  </div>
                )}
              </div>}
            </>}
          </>
        )}
      </div>
    </div>
  );
}

export default function App(){
  const [tab,setTab]=useState("dashboard");
  const [fD,setFD]=useState("All");
  const [fS,setFS]=useState("All");
  const [fT,setFT]=useState("All");
  const [selP,setSelP]=useState(null);
  const [ctrP,setCtrP]=useState(null);
  const [intake,setIntake]=useState(false);
  const [form,setForm]=useState({job:"",client:"",city:"",type:"Room Addition",designer:"Radovan",contract:"",notes:""});

  const [projects,setProjects]=useState(PROJECTS_INIT);
  const [showImport,setShowImport]=useState(false);
  const [importing,setImporting]=useState(false);
  const [importStep,setImportStep]=useState("");
  const [importError,setImportError]=useState("");

  const DS=["All",...Object.keys(DC)];
  const SS=["All","In Progress","Completed","On Hold","Not Started"];
  const TS=["All","Room Addition","ADU - New","ADU - Garage Conv.","Garage Conv.","Commercial Int.","High Ceiling Conv."];
  const filtered=useMemo(()=>projects.filter(p=>(fD==="All"||p.designer===fD)&&(fS==="All"||p.status===fS)&&(fT==="All"||p.type===fT)),[projects,fD,fS,fT]);
  const active=projects.filter(p=>p.status==="In Progress").length;
  const done=projects.filter(p=>p.status==="Completed").length;
  const avgP=Math.round(projects.filter(p=>p.status==="In Progress").reduce((a,p)=>a+p.pct,0)/Math.max(active,1));
  const totC=projects.reduce((a,p)=>a+p.contract,0);
  const totI=projects.reduce((a,p)=>a+p.invoiced,0);

  async function importFromPDF(file){
    setImporting(true);setImportError("");setImportStep("Reading PDF...");
    try{
      const b64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
      setImportStep("AI is analyzing contract...");
      const apiRes=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        model:"claude-sonnet-4-20250514",max_tokens:1000,
        messages:[{role:"user",content:[
          {type:"document",source:{type:"base64",media_type:"application/pdf",data:b64}},
          {type:"text",text:`You are a project manager at TruPlans Inc., a California architectural design firm. Extract all info from this contract. Return ONLY valid JSON, no markdown, no backticks:
{"project":{"id":"TRU-NEW","name":"short project name","client":"full client name","city":"city","type":"High Ceiling Conv.|Room Addition|ADU - New|ADU - Garage Conv.|Garage Conv.|Commercial Int.|New Construction","designer":"Radovan","status":"In Progress","phase":"Design Dev","start":"YYYY-MM-DD","end":"YYYY-MM-DD","pct":0,"stamp":"No","permit":"No","contract":0,"invoiced":0},"contractData":{"id":"CTR-NEW","type":"Design + Construction","contractor":"contractor name","contractorLic":"license","signedDate":"YYYY-MM-DD","totalAmount":0,"estStart":"YYYY-MM-DD","estCompletion":"YYYY-MM-DD","constructionWeeks":"3-4","docusignId":"","designScope":[{"id":"0001","label":"Planning, Zoning & Research","included":true,"status":"Not Started"},{"id":"0002","label":"Design Meeting(s)","included":true,"status":"Not Started"},{"id":"0003","label":"Wholesale Showroom Access","included":true,"status":"N/A"},{"id":"0004","label":"Architectural Plans / Construction Documents","included":true,"status":"Not Started"},{"id":"0005","label":"Title 24 Energy Report","included":true,"status":"Not Started"},{"id":"0006","label":"HOA Package & Submission","included":true,"status":"Not Started"},{"id":"0008","label":"Structural Drawings & Engineer Wet Stamp","included":true,"status":"Not Started"},{"id":"0009","label":"Plan Check & Permit Process","included":true,"status":"Not Started"}],"constructionScope":[{"id":"0100","label":"Pre-Construction Meeting","included":true,"status":"Not Started"},{"id":"0101","label":"Site Protection","included":true,"status":"Not Started"},{"id":"0102","label":"Demolition & Shoring","included":true,"status":"Not Started"},{"id":"0103","label":"Debris & Haul Away","included":true,"status":"Not Started"},{"id":"0104","label":"New Footings","included":false,"status":"N/A"},{"id":"0151","label":"Retrofit Structural Shear Wall","included":false,"status":"N/A"},{"id":"0153","label":"Interior Walls","included":false,"status":"N/A"},{"id":"0154","label":"Low Wall (Pony Wall)","included":true,"status":"Not Started"},{"id":"0155","label":"Floor System Framing","included":true,"status":"Not Started"},{"id":"0175","label":"Forced Air Unit (FAU)","included":false,"status":"N/A"},{"id":"0177","label":"Air Ducts / Vents","included":true,"status":"Not Started"},{"id":"0201","label":"Electrical Panel Upgrade","included":false,"status":"N/A"},{"id":"0202","label":"New Electrical Circuits","included":true,"status":"Not Started"},{"id":"0203","label":"Power Outlets","included":true,"status":"Not Started"},{"id":"0204","label":"Recessed Lights","included":true,"status":"Not Started"},{"id":"0206","label":"Light Switches","included":true,"status":"Not Started"},{"id":"0210","label":"Smoke & CO Detectors","included":true,"status":"Not Started"},{"id":"0330","label":"Fire Sprinklers","included":true,"status":"Not Started"},{"id":"0400","label":"Stucco / Siding Repair","included":true,"status":"Not Started"},{"id":"0404","label":"Thermal Insulation","included":true,"status":"Not Started"},{"id":"0405","label":"Insulate Floor System","included":true,"status":"Not Started"},{"id":"0406","label":"Drywall","included":true,"status":"Not Started"},{"id":"0407","label":"Misc Drywall Patching","included":true,"status":"Not Started"},{"id":"0700","label":"Interior Doors","included":false,"status":"N/A"},{"id":"0708","label":"New Construction Windows","included":true,"status":"Not Started"},{"id":"0752","label":"Baseboards","included":true,"status":"Not Started"},{"id":"0754","label":"Stair / Balcony Railing","included":true,"status":"Not Started"},{"id":"0758","label":"Finish Flooring","included":false,"status":"N/A"},{"id":"0759","label":"Painting / Staining","included":false,"status":"N/A"}],"paymentMilestones":[],"homeownerObligations":[{"id":"ho1","label":"Provide house key / lockbox","done":false},{"id":"ho2","label":"Alarm system access / codes","done":false},{"id":"ho3","label":"HOA contact info submitted","done":false},{"id":"ho4","label":"Signed HOA application + neighbor form","done":false},{"id":"ho5","label":"HOA application fee paid","done":false},{"id":"ho6","label":"All plan check & permit fees paid by homeowner","done":false},{"id":"ho7","label":"Maintain utilities during construction","done":false},{"id":"ho8","label":"Punch list within 7 days of completion","done":false}],"hiddenConditionFlags":[{"id":"hc1","label":"New Footings required","flagged":false,"notes":""},{"id":"hc2","label":"Retrofit Shear Wall required","flagged":false,"notes":""},{"id":"hc3","label":"Lateral analysis required","flagged":false,"notes":""},{"id":"hc4","label":"T24 / HERS failure risk","flagged":false,"notes":""},{"id":"hc5","label":"Electrical panel inadequate","flagged":false,"notes":""},{"id":"hc6","label":"Mold / structural damage found","flagged":false,"notes":""},{"id":"hc7","label":"Duct soffit required","flagged":false,"notes":""}],"changeOrders":[],"aiAnalysis":{"generatedAt":"TODAY","summary":"summary here","scopeSummary":"scope bullets","paymentSummary":"payment summary","obligations":"TruPlans obligations","riskFlags":[{"level":"HIGH","text":"risk"}],"actionItems":[{"done":false,"text":"action item"}]}}}
Set included:true/false per contract. Extract real payment milestones with amounts. project.contract=totalAmount. project.invoiced=deposit if paid else 0.`}
        ]}]})});
      setImportStep("Building project...");
      const d=await apiRes.json();
      const raw=d.content?.[0]?.text||"{}";
      const parsed=JSON.parse(raw.replace(/```json|```/g,"").trim());
      const {project,contractData}=parsed;
      const maxId=projects.reduce((mx,p)=>{const n=parseInt(p.id.replace("TRU-",""))||0;return Math.max(mx,n);},0);
      const newId="TRU-"+String(maxId+1).padStart(3,"0");
      project.id=newId;
      contractData.id="CTR-"+Date.now();
      if(contractData.aiAnalysis) contractData.aiAnalysis.generatedAt=new Date().toISOString().slice(0,10);
      setProjects(prev=>[...prev,{...project,contracts:[contractData]}]);
      setImporting(false);setShowImport(false);setTab("projects");
    }catch(e){setImportError("Error: "+e.message);setImporting(false);}
  }
  const todayL=((new Date()-GANTT_S)/86400000/TDAYS*100).toFixed(2);
  const MTHS=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

  const PM=()=>{
    if(!selP)return null;const p=selP;
    return<div style={S.ov} onClick={()=>setSelP(null)}><div style={S.mod} onClick={e=>e.stopPropagation()}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:20}}><div><div style={{fontSize:10,color:"#e94560",letterSpacing:"2px",fontFamily:"monospace"}}>{p.id}</div><div style={{fontSize:18,fontWeight:700,color:"#f0f0f0"}}>{p.name}</div><div style={{fontSize:12,color:"#888"}}>{p.client} · {p.city}</div></div><Sb status={p.status}/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:16}}>{[["Contract",fmt$(p.contract)],["Invoiced",fmt$(p.invoiced)],["Balance",fmt$(p.contract-p.invoiced)]].map(([l,v])=><div key={l} style={{background:"#0d0d1a",borderRadius:6,padding:"12px"}}><div style={{fontSize:9,color:"#888",letterSpacing:"1px",textTransform:"uppercase",fontFamily:"monospace"}}>{l}</div><div style={{fontSize:16,fontWeight:700,color:"#f0f0f0",marginTop:4}}>{v}</div></div>)}</div>
      <div style={{marginBottom:16}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:10,color:"#888",fontFamily:"monospace"}}><span>Progress</span><span style={{color:"#e94560"}}>{p.pct}%</span></div><Pb pct={p.pct}/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:20,fontSize:11}}>{[["Phase",p.phase],["Type",p.type],["Designer",p.designer],["Start",p.start],["Target",p.end],["Eng. Stamp",p.stamp],["Permit",p.permit],["Contracts",p.contracts.length>0?`${p.contracts.length} attached`:"None"]].map(([l,v])=><div key={l} style={{background:"#0d0d1a",padding:"8px 10px",borderRadius:4,display:"flex",gap:8}}><span style={{color:"#555",minWidth:72,fontFamily:"monospace",fontSize:10}}>{l}:</span><span style={{color:"#ccc"}}>{v}</span></div>)}</div>
      <div style={{display:"flex",gap:8,justifyContent:"flex-end"}}><button style={S.btn} onClick={()=>{setCtrP(p);setSelP(null);}}>📄 Contracts</button><button style={S.ghost} onClick={()=>setSelP(null)}>Close</button></div>
    </div></div>;
  };

  const IM=()=>(
    <div style={S.ov}><div style={S.mod}><div style={{marginBottom:20}}><div style={{fontSize:11,color:"#e94560",letterSpacing:"2px",fontFamily:"monospace"}}>NEW PROJECT</div><div style={{fontSize:18,fontWeight:700,color:"#f0f0f0"}}>Job Intake Form</div></div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
      {[["Job Number","job","text"],["Client Name","client","text"],["City","city","text"],["Fee ($)","contract","number"]].map(([l,k,t])=><div key={k}><label style={S.label}>{l}</label><input type={t} style={S.input} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/></div>)}
      <div><label style={S.label}>Type</label><select style={{...S.input,width:"100%"}} value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>{TS.slice(1).map(t=><option key={t}>{t}</option>)}</select></div>
      <div><label style={S.label}>Designer</label><select style={{...S.input,width:"100%"}} value={form.designer} onChange={e=>setForm({...form,designer:e.target.value})}>{Object.keys(DC).map(d=><option key={d}>{d}</option>)}</select></div>
      <div style={{gridColumn:"1/-1"}}><label style={S.label}>Notes</label><textarea style={{...S.input,height:70,resize:"vertical"}} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></div>
    </div>
    <div style={{marginTop:20,display:"flex",gap:8,justifyContent:"flex-end"}}><button style={S.ghost} onClick={()=>setIntake(false)}>Cancel</button><button style={S.btn} onClick={()=>setIntake(false)}>Save</button></div>
    </div></div>
  );

  const Dash=()=>(
    <>
      <div style={{display:"flex",gap:12,marginBottom:24,flexWrap:"wrap"}}>
        {[["Active",active,"#5bb8f5"],["Avg Progress",avgP+"%","#e94560"],["Completed",done,"#52d68a"],["Total Contract",fmt$(totC),"#f0a842"],["Invoiced",fmt$(totI),"#9b59b6"],["Outstanding",fmt$(totC-totI),"#e74c3c"]].map(([l,v,c])=><div key={l} style={S.metric}><div style={{fontSize:9,color:"#666",letterSpacing:"2px",textTransform:"uppercase",fontFamily:"monospace",marginBottom:8}}>{l}</div><div style={{fontSize:22,fontWeight:700,color:c,fontFamily:"monospace"}}>{v}</div></div>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:24}}>
        <div style={S.card}><ST>Designer Workload</ST>{Object.keys(DC).filter(d=>d!=="Chris"&&d!=="Ayana").map(d=>{const dp=projects.filter(p=>p.designer===d&&p.status==="In Progress");return<div key={d} style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}><Av name={d}/><div style={{flex:1}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:11,color:"#ccc"}}>{d}</span><span style={{fontSize:10,color:"#888",fontFamily:"monospace"}}>{dp.length} active</span></div><Pb pct={dp.length/5*100} color={DC[d]}/></div></div>;})}</div>
        <div style={S.card}><ST>Phase Distribution</ST>{PHASES.map(ph=>{const n=projects.filter(p=>p.phase===ph).length;if(!n)return null;return<div key={ph} style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}><div style={{fontSize:10,color:"#888",minWidth:110,fontFamily:"monospace"}}>{ph}</div><div style={{flex:1,background:"#0d0d1a",borderRadius:99,height:6,overflow:"hidden"}}><div style={{height:"100%",width:(n/projects.length*100)+"%",background:"#e94560",borderRadius:99}}/></div><div style={{fontSize:11,color:"#e94560",fontFamily:"monospace",minWidth:16,textAlign:"right"}}>{n}</div></div>;})}</div>
      </div>
      <div style={S.card}><ST>Urgent Tasks</ST>
        <table style={S.tbl}><thead><tr>{["Job","Task","Assigned","Due","Priority","Status"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
        <tbody>{TASKS_INIT.filter(t=>t.priority==="High").map((t,i)=><tr key={i} style={{background:i%2===0?"transparent":"#0a0a18"}}><td style={{...S.td,color:"#e94560",fontFamily:"monospace",fontSize:10}}>{t.job}</td><td style={{...S.td,color:"#ccc"}}>{t.desc}</td><td style={S.td}><div style={{display:"flex",alignItems:"center",gap:6}}><Av name={t.assigned} size={22}/><span style={{fontSize:10,color:"#aaa"}}>{t.assigned}</span></div></td><td style={{...S.td,color:"#f0a842",fontFamily:"monospace",fontSize:10}}>{t.due}</td><td style={S.td}><span style={{color:PRIORITY_COLOR[t.priority],fontSize:10,fontWeight:700}}>{t.priority}</span></td><td style={S.td}><Sb status={t.status}/></td></tr>)}</tbody></table>
      </div>
    </>
  );

  const Projs=()=>(
    <>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
          {[[DS,fD,setFD],[SS,fS,setFS],[TS,fT,setFT]].map((a,i)=><select key={i} style={S.sel} value={a[1]} onChange={e=>a[2](e.target.value)}>{a[0].map(o=><option key={o}>{o}</option>)}</select>)}
          <span style={{fontSize:10,color:"#444",fontFamily:"monospace"}}>{filtered.length} projects</span>
        </div>
        <div style={{display:"flex",gap:8}}><button style={{...S.ghost}} onClick={()=>setShowImport(true)}>📄 Import from Contract</button><button style={S.btn} onClick={()=>setIntake(true)}>+ New Project</button></div>
      </div>
      <table style={S.tbl}>
        <thead><tr>{["Job #","Project","Client","Type","Designer","Phase","Status","Progress","Contract","Balance","Contracts","Action"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
        <tbody>{filtered.map((p,i)=><tr key={p.id} style={{background:i%2===0?"transparent":"#0a0a18",cursor:"pointer"}} onClick={()=>setSelP(p)}>
          <td style={{...S.td,color:"#e94560",fontFamily:"monospace",fontSize:10,fontWeight:700}}>{p.id}</td>
          <td style={{...S.td,color:"#f0f0f0",maxWidth:160}}>{p.name}</td>
          <td style={{...S.td,color:"#aaa",fontSize:10}}>{p.client}</td>
          <td style={{...S.td,color:"#888",fontSize:10}}>{p.type}</td>
          <td style={S.td}><div style={{display:"flex",alignItems:"center",gap:6}}><Av name={p.designer} size={22}/><span style={{fontSize:10,color:"#aaa"}}>{p.designer}</span></div></td>
          <td style={{...S.td,fontSize:10,color:"#9b59b6"}}>{p.phase}</td>
          <td style={S.td}><Sb status={p.status}/></td>
          <td style={{...S.td,minWidth:80}}><div style={{display:"flex",alignItems:"center",gap:6}}><div style={{flex:1,minWidth:50}}><Pb pct={p.pct}/></div><span style={{fontSize:9,color:"#888",fontFamily:"monospace"}}>{p.pct}%</span></div></td>
          <td style={{...S.td,color:"#f0f0f0",fontFamily:"monospace",fontSize:10}}>{fmt$(p.contract)}</td>
          <td style={{...S.td,color:p.contract-p.invoiced>0?"#f0a842":"#52d68a",fontFamily:"monospace",fontSize:10}}>{fmt$(p.contract-p.invoiced)}</td>
          <td style={S.td} onClick={e=>{e.stopPropagation();setCtrP(p);}}><span style={{fontSize:10,color:p.contracts.length>0?"#e94560":"#444",cursor:"pointer",fontFamily:"monospace",fontWeight:700}}>{p.contracts.length>0?`📄 ${p.contracts.length}`:"+ Add"}</span></td>
          <td style={S.td}><button style={{...S.ghost,padding:"3px 10px",fontSize:10}} onClick={e=>{e.stopPropagation();setSelP(p);}}>View</button></td>
        </tr>)}</tbody>
      </table>
    </>
  );

  const Gantt=()=>(
    <div style={{...S.card,overflowX:"auto"}}>
      <ST>2026 Project Timeline</ST>
      <div style={{display:"flex",marginBottom:4,marginLeft:260}}>{MTHS.map((m,i)=><div key={i} style={{flex:1,textAlign:"center",fontSize:9,color:"#e94560",fontFamily:"monospace",borderLeft:"1px solid #1a1a2e",paddingLeft:2}}>{m}</div>)}</div>
      {projects.map((p,i)=>{const bar=gBar(p.start,p.end),color=Object.values(DC)[i%6];return<div key={p.id} style={{display:"flex",alignItems:"center",marginBottom:4,minWidth:900}}>
        <div style={{width:260,flexShrink:0,display:"flex",alignItems:"center",gap:6,paddingRight:10}}><Av name={p.designer} size={20}/><div style={{overflow:"hidden"}}><div style={{fontSize:10,color:"#e94560",fontFamily:"monospace"}}>{p.id}</div><div style={{fontSize:10,color:"#ccc",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:190}}>{p.name}</div></div></div>
        <div style={{flex:1,position:"relative",height:22,background:"#0d0d1a",borderRadius:2}}>
          {MTHS.map((_,mi)=><div key={mi} style={{position:"absolute",left:(mi/12*100)+"%",top:0,bottom:0,width:1,background:"#1a1a2e"}}/>)}
          <div style={{position:"absolute",left:todayL+"%",top:-2,bottom:-2,width:1.5,background:"#e94560",zIndex:10}}/>
          <div style={{position:"absolute",left:bar.left,width:bar.width,top:3,bottom:3,background:color+"cc",borderRadius:3,display:"flex",alignItems:"center",paddingLeft:4,overflow:"hidden",border:`1px solid ${color}`}}>
            <span style={{fontSize:8,color:"#fff",whiteSpace:"nowrap",fontWeight:700,fontFamily:"monospace"}}>{p.pct}%</span>
            <div style={{position:"absolute",left:0,top:0,bottom:0,width:p.pct+"%",background:color,opacity:0.4,borderRadius:3}}/>
          </div>
        </div>
        <div style={{width:100,flexShrink:0,paddingLeft:8,fontSize:9,color:"#555",fontFamily:"monospace"}}>{p.phase}</div>
      </div>;})}
    </div>
  );

  const Tasks=()=>(
    <table style={S.tbl}><thead><tr>{["Job","Task","Assigned","Priority","Status","Due"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
    <tbody>{TASKS_INIT.map((t,i)=><tr key={i} style={{background:i%2===0?"transparent":"#0a0a18"}}><td style={{...S.td,color:"#e94560",fontFamily:"monospace",fontSize:10,fontWeight:700}}>{t.job}</td><td style={{...S.td,color:"#ccc"}}>{t.desc}</td><td style={S.td}><div style={{display:"flex",alignItems:"center",gap:6}}><Av name={t.assigned} size={22}/><span style={{fontSize:10,color:"#aaa"}}>{t.assigned}</span></div></td><td style={S.td}><span style={{color:PRIORITY_COLOR[t.priority],fontSize:10,fontWeight:700,fontFamily:"monospace"}}>{t.priority}</span></td><td style={S.td}><Sb status={t.status}/></td><td style={{...S.td,color:"#f0a842",fontFamily:"monospace",fontSize:10}}>{t.due}</td></tr>)}</tbody></table>
  );

  const ImportModal=()=>(
    <div style={S.ov} onClick={()=>!importing&&setShowImport(false)}>
      <div style={{...S.mod,maxWidth:520}} onClick={e=>e.stopPropagation()}>
        <div style={{marginBottom:20}}>
          <div style={{fontSize:10,color:"#e94560",letterSpacing:"2px",fontFamily:"monospace"}}>AUTO-IMPORT</div>
          <div style={{fontSize:18,fontWeight:700,color:"#f0f0f0",marginTop:2}}>Create Project from Contract PDF</div>
          <div style={{fontSize:11,color:"#888",marginTop:4}}>Upload a signed contract PDF. AI will extract all details and create the project automatically — including scope checklist, payment milestones, risk flags, and action items.</div>
        </div>
        {!importing?(
          <div>
            <label style={{display:"block",border:"2px dashed #2a2a4a",borderRadius:8,padding:"32px",textAlign:"center",cursor:"pointer",background:"#0a0a15",transition:"border-color .2s"}}
              onDragOver={e=>{e.preventDefault();}}
              onDrop={e=>{e.preventDefault();const f=e.dataTransfer.files[0];if(f&&f.type==="application/pdf")importFromPDF(f);}}>
              <input type="file" accept=".pdf" style={{display:"none"}} onChange={e=>e.target.files[0]&&importFromPDF(e.target.files[0])}/>
              <div style={{fontSize:36,marginBottom:8}}>📄</div>
              <div style={{fontSize:13,color:"#ccc",marginBottom:4}}>Click to select PDF or drag & drop here</div>
              <div style={{fontSize:10,color:"#555",fontFamily:"monospace"}}>Accepts: CALOFT / TruPlans contract PDFs</div>
            </label>
            {importError&&<div style={{marginTop:12,color:"#e74c3c",fontSize:11,padding:"8px 12px",background:"#1a0808",borderRadius:4}}>{importError}</div>}
            <div style={{marginTop:16,display:"flex",justifyContent:"flex-end"}}><button style={S.ghost} onClick={()=>setShowImport(false)}>Cancel</button></div>
          </div>
        ):(
          <div style={{textAlign:"center",padding:"32px 0"}}>
            <div style={{fontSize:36,marginBottom:16,animation:"spin 1s linear infinite"}}>⏳</div>
            <div style={{fontSize:14,color:"#f0f0f0",marginBottom:8}}>{importStep}</div>
            <div style={{fontSize:11,color:"#555",fontFamily:"monospace"}}>This takes about 15–20 seconds...</div>
            <div style={{marginTop:20}}><Pb pct={importStep.includes("Building")?90:importStep.includes("Processing")?70:importStep.includes("AI")?40:10} color="#e94560"/></div>
          </div>
        )}
      </div>
    </div>
  );

  return(
    <div style={S.app}>
      {selP&&<PM/>}
      {ctrP&&<ContractModule project={ctrP} onClose={()=>setCtrP(null)}/>}
      {intake&&<IM/>}
      {showImport&&<ImportModal/>}
      <nav style={S.nav}>
        <div style={S.logo}>TRUPLANS</div>
        {[["dashboard","Dashboard"],["projects","Projects"],["gantt","Gantt"],["tasks","Tasks"]].map(([id,l])=><button key={id} style={S.tab(tab===id)} onClick={()=>setTab(id)}>{l}</button>)}
        <div style={{marginLeft:"auto",fontSize:10,color:"#333",fontFamily:"monospace"}}>{new Date().toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"})}</div>
      </nav>
      <main style={S.main}>
        {tab==="dashboard"&&<Dash/>}
        {tab==="projects"&&<Projs/>}
        {tab==="gantt"&&<Gantt/>}
        {tab==="tasks"&&<Tasks/>}
      </main>
    </div>
  );
}
