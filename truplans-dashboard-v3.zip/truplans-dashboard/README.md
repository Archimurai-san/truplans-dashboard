# TruPlans Project Dashboard

A local project management dashboard for TruPlans Inc.
Built with React + Vite. Runs entirely on your computer — no internet needed after setup.

---

## STEP 1 — Install Node.js (one time only)

1. Go to: https://nodejs.org
2. Download the **LTS** version (green button)
3. Run the installer — click Next through all steps
4. When done, open a terminal to verify:
   - Windows: press Win+R, type `cmd`, press Enter
   - Mac: open Terminal (Applications > Utilities > Terminal)
   - Type: `node --version`  → should show something like v20.x.x
   - Type: `npm --version`   → should show something like 10.x.x

---

## STEP 2 — Set up the project (one time only)

1. Copy the `truplans-dashboard` folder anywhere on your computer
   (e.g. Desktop, Documents, wherever you keep work files)

2. Open a terminal and navigate to the folder:
   ```
   cd path/to/truplans-dashboard
   ```
   Example on Windows:
   ```
   cd C:\Users\Radovan\Desktop\truplans-dashboard
   ```
   Example on Mac:
   ```
   cd ~/Desktop/truplans-dashboard
   ```

3. Install dependencies (downloads React and Vite — takes ~30 seconds):
   ```
   npm install
   ```

---

## STEP 3 — Run the dashboard

Every time you want to open the dashboard:

```
npm run dev
```

Then open your browser and go to:
**http://localhost:5173**

The dashboard will open. It auto-refreshes when you edit any file.

To stop it: press `Ctrl + C` in the terminal.

---

## Editing your project data

All project data lives in one file:

```
src/App.jsx
```

Open it in any text editor (Notepad, VS Code, etc.).

Look for the `PROJECTS` array near the top — each line is one project.
Look for the `TASKS` array — each line is one task.

Just edit the values and save — the browser updates automatically.

---

## Recommended free code editor

**VS Code** — https://code.visualstudio.com
Much easier than Notepad for editing .jsx files. Has color coding and autocomplete.

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `npm: command not found` | Node.js not installed — redo Step 1 |
| `npm install` errors | Make sure you're inside the truplans-dashboard folder |
| Browser shows blank page | Check terminal for error messages |
| Port 5173 already in use | Another app is running — Vite will auto-use 5174 instead |
